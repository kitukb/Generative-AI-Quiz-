<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Plugin strings are defined here.
 *
 * @package     mod_generativeaiv2
 * @category    string
 * @copyright   2024 Ken M. Mbabu <kencerm08@gmail.com>
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['modulename'] = 'Generative AI Quiz';
$string['modulenameplural'] = 'Generative AI Quizzes';
$string['modulename_help'] = 'Use the Generative AI Quiz module to dynamically generate questions based on user performance.';
$string['pluginname'] = 'GenerativeAI Quiz';
$string['pluginadministration'] = 'GenerativeAI Quiz Administration';
$string['generativeaiv2name'] = 'Multiple Choice AI Quiz Name';
$string['generativeaiv2settings'] = 'GenerativeAI Quiz Settings';
$string['generativeaiv2fieldset'] = 'GenerativeAI Quiz Settings';
$string['topic'] = 'Quiz Topic(s)';
$string['topic_help'] = 'Specify the topic for the quiz, which will guide question generation.';
$string['startdifficulty'] = 'Difficulty Level';
$string['startdifficulty_help'] = 'Select the initial difficulty level for the quiz.<br>Easy means knowledge or comprehension level of blooms taxonomy<br>Medium means application and analysis level of blooms taxonomy<br>Hard means evaluation and synthesis level of blooms taxonomy';
$string['maxquestions'] = 'Maximum Questions';
$string['maxquestions_help'] = 'Specify the maximum number of questions for the quiz. The quiz will end once this number is reached.';
$string['timelimit'] = 'Time limit in Minutes';
$string['timelimit_help'] = 'Specify the time in minutes that the student should attempt the given questions. The quiz will end and submit once this time elapses.';
$string['easy'] = 'Easy';
$string['medium'] = 'Medium';
$string['hard'] = 'Hard';
$string['apikey'] = 'OpenAI API Key';
$string['apikey_desc'] = 'Enter your OpenAI API Key for generating questions.';
$string['grade1'] = 'Grade 1';
$string['grade2'] = 'Grade 2';
$string['grade3'] = 'Grade 3';
$string['grade4'] = 'Grade 4';
$string['grade5'] = 'Grade 5';
$string['grade6'] = 'Grade 6';
$string['grade7'] = 'Grade 7';
$string['grade8'] = 'Grade 8';
$string['grade9'] = 'Grade 9';
$string['grade10'] = 'Grade 10';
$string['grade11'] = 'Grade 11';
$string['grade12'] = 'Grade 12';
$string['year1'] = '1st Year';
$string['year2'] = '2nd Year';
$string['year3'] = '3rd Year';
$string['year4'] = '4th Year';
$string['contextlevel'] = 'Student level';
$string['contextlevel_help'] = 'Select the level at which evaluation should be done (example: Year 1 - Questions for students in 1st year, university level).';
$string['contextinfo'] = 'Specialization or student type';
$string['contextinfo_help'] = 'Type additional information about the student level at which evaluation should be done (example: computer science University students). This determines kind of questions that will be generated for that level.';
$string['additionalinfo'] = 'Additional Information to the prompt';
$string['additionalinfo_help'] = 'Include any additional information to be included in the prompt.';
$string['apikey'] = 'Chat GPT API Key (optional if was entered during installation)';
$string['apikey_help'] = 'Enter the API key for the GPT service. This field overrides the system key entered during installation. The field is optional if the system key exists otherwise, no questions will be generated.';
$string['gpt-3.5-turbo'] = 'GPT 3.5 Model';
$string['gpt-4-turbo'] = 'GPT 4 Model';
$string['modeloptions'] = 'Select GPT model';
$string['modeloptions_help'] = 'Select the model that you want the GPT to use to generate the questions';

//Reports: General
$string['quiz_analysis'] = 'Quiz Analysis Report';
$string['quizanalysisreport'] = 'Quiz Analysis Report';

// Column Headers
$string['firstname'] = 'First Name';
$string['lastname'] = 'Last Name';
$string['email'] = 'Email';
$string['quizname'] = 'Quiz Name';
$string['totalquestions'] = 'Total Questions';
$string['correctanswers'] = 'Correct Answers';
$string['failedanswers'] = 'Failed Answers';

// Filters
$string['quizid'] = 'Quiz ID';

// Chart Titles
$string['quiz_performance'] = 'Quiz Performance Overview';

// Messages
$string['report_nodata'] = 'No data available for this quiz.';
$string['report_error'] = 'Error fetching report data.';