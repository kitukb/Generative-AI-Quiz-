<?php
$services = [
    'mod_generativeaiv2_reports' => [
        'classname'   => 'mod_generativeaiv2\report\quiz_analysis_report',
        'classpath'   => '',
        'component'   => 'mod_generativeaiv2',
        'capabilities' => 'mod/generativeaiv2:viewreports',
        'ajax'        => true,
        'loginrequired' => true,
    ],
];