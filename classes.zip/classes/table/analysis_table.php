<?php
namespace mod_generativeaiv2\table;

defined('MOODLE_INTERNAL') || die(); // Ensure the script is not accessed directly

global $CFG;
require_once($CFG->libdir . '/tablelib.php'); // Correct way to include Moodle's table library

use table_sql;

class analysis_table extends table_sql {
    public function __construct($uniqueid) {
        parent::__construct($uniqueid);

        // Define table columns and headers
        $this->define_columns(['student_name', 'email', 'quiz_name', 'total_questions', 'correct_answers', 'failed_answers']);
        $this->define_headers(['Student Name', 'Email', 'Quiz Name', 'Total Questions', 'Correct Answers', 'Failed Answers']);

        // Enable sorting
        $this->sortable(true, 'student_name', SORT_DESC);
    }

    public function col_student_name($row) {
        return format_string($row->student_name);
    }

    public function col_email($row) {
        return s($row->email);
    }

    public function col_quiz_name($row) {
        return format_string($row->quiz_name);
    }

    public function col_total_questions($row) {
        return $row->total_questions;
    }

    public function col_correct_answers($row) {
        return "<span style='color: green; font-weight: bold;'>{$row->correct_answers}</span>";
    }

    public function col_failed_answers($row) {
        return "<span style='color: red; font-weight: bold;'>{$row->failed_answers}</span>";
    }
}