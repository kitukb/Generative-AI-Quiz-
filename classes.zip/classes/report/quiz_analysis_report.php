<?php
namespace mod_generativeaiv2\report;

defined('MOODLE_INTERNAL') || die();

class quiz_analysis_report extends \core_reportbuilder\local\report\base_report {
    protected function define_columns() {
        return [
            'u.firstname' => get_string('firstname'),
            'u.lastname' => get_string('lastname'),
            'u.email' => get_string('email'),
            'q.name' => get_string('quizname', 'mod_generativeaiv2'),
            'total_questions' => get_string('totalquestions', 'mod_generativeaiv2'),
            'correct_answers' => get_string('correctanswers', 'mod_generativeaiv2'),
            'failed_answers' => get_string('failedanswers', 'mod_generativeaiv2'),
        ];
    }

    protected function define_filters() {
        return [
            'quizid' => [
                'label' => get_string('quizid', 'mod_generativeaiv2'),
                'type'  => \core_reportbuilder\local\filter\integer_filter::class,
            ],
        ];
    }

    protected function define_source() {
        return "mdl_generativeaiv2_user_response ur
                JOIN mdl_user u ON ur.userid = u.id
                JOIN mdl_generativeaiv2_questions q ON ur.quizid = q.id";
    }

    protected function define_sql() {
        error_log("Generated SQL: " . print_r($this->define_sql(), true));
        return [
            'fields' => 'u.id AS userid, u.firstname, u.lastname, u.email, 
                         q.quizid, COUNT(ur.questionid) AS total_questions,
                         SUM(CASE WHEN ur.correct = 1 THEN 1 ELSE 0 END) AS correct_answers,
                         SUM(CASE WHEN ur.correct = 0 THEN 1 ELSE 0 END) AS failed_answers',
            'from' => '{generativeaiv2_user_response} ur
                       JOIN {user} u ON ur.userid = u.id
                       JOIN {generativeaiv2_questions} q ON ur.quizid = q.quizid',
            'groupby' => 'u.id, q.quizid',
        ];
        // return [
        //     'fields' => 'u.id AS userid,CONCAT(u.firstname, " ", u.lastname) AS student_name,u.email,qz.name AS quiz_name,COUNT(DISTINCT q.id) AS total_questions,SUM(CASE WHEN ur.correct = 1 THEN 1 ELSE 0 END) AS correct_answers,SUM(CASE WHEN ur.correct = 0 THEN 1 ELSE 0 END) AS failed_answers',

        //     'from' => 'mdl_generativeaiv2_user_response ur JOIN mdl_user u ON ur.userid = u.id JOIN mdl_generativeaiv2_questions q ON ur.questionid = q.id JOIN mdl_generativeaiv2 qz ON qz.id = ur.quizid',

        //     'groupby' => 'u.id, qz.id',
        // ];
    }
}
// namespace mod_generativeaiv2\report;

// use core_reportbuilder\local\report\base;
// use core_reportbuilder\local\entities\user;
// use core_reportbuilder\local\filters\integer;
// use core_reportbuilder\local\helpers\format_helper;
// use core_reportbuilder\output\component\chart;

// class quiz_analysis_report extends base {

//     protected function define_entities(): void {
//         // Add the user entity (Student details)
//         $this->add_entity(new user('u'));

//         // Custom SQL Entity for quiz data
//         $this->add_entity(new \core_reportbuilder\local\entities\custom_sql('qa', "
//             {generativeaiv2_user_response} qa
//             JOIN {generativeaiv2_questions} q ON qa.questionid = q.id
//             JOIN {user} u ON qa.userid = u.id
//             JOIN {quiz} qu ON q.quizid = qu.id
//         "));
//     }

//     protected function define_columns(): void {
//         $this->add_column('u.firstname', get_string('firstname', 'core'));
//         $this->add_column('u.lastname', get_string('lastname', 'core'));
//         $this->add_column('u.email', get_string('email', 'core'));
//         $this->add_column('qu.name', get_string('quizname', 'mod_quiz'));
//         $this->add_column_sql("COUNT(q.id)", "total_questions", get_string('totalquestions', 'mod_generativeaiv2'));
//         $this->add_column_sql("SUM(CASE WHEN qa.correct = 1 THEN 1 ELSE 0 END)", "correct_answers", get_string('correctanswers', 'mod_generativeaiv2'));
//         $this->add_column_sql("SUM(CASE WHEN qa.correct = 0 THEN 1 ELSE 0 END)", "failed_answers", get_string('failedanswers', 'mod_generativeaiv2'));
//     }

//     protected function define_filters(): void {
//         // Filter by Quiz ID
//         $this->add_filter('qa.quizid', integer::class, [
//             'label' => get_string('quizid', 'mod_generativeaiv2')
//         ]);
//     }

//     protected function define_chart(): ?chart {
//         $chart = new chart(get_string('quiz_performance', 'mod_generativeaiv2'));

//         $chart->add_series_sql(get_string('correctanswers', 'mod_generativeaiv2'), "
//             SELECT u.id, u.firstname, SUM(CASE WHEN qa.correct = 1 THEN 1 ELSE 0 END) AS count
//             FROM {generativeaiv2_user_response} qa
//             JOIN {user} u ON qa.userid = u.id
//             GROUP BY u.id, u.firstname
//         ");

//         $chart->add_series_sql(get_string('failedanswers', 'mod_generativeaiv2'), "
//             SELECT u.id, u.firstname, SUM(CASE WHEN qa.correct = 0 THEN 1 ELSE 0 END) AS count
//             FROM {generativeaiv2_user_response} qa
//             JOIN {user} u ON qa.userid = u.id
//             GROUP BY u.id, u.firstname
//         ");

//         return $chart;
//     }