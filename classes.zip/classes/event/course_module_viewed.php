<?php
namespace mod_generativeaiv2\event;

defined('MOODLE_INTERNAL') || die();

/**
 * The mod_generativeaiv2 instance viewed event class.
 *
 * This event is triggered when a user views a Generative AI module instance.
 */
class course_module_viewed extends \core\event\course_module_viewed {
    
    /**
     * Initialize the event data.
     */
    protected function init() {
        $this->data['crud'] = 'r'; // 'r' for read
        $this->data['edulevel'] = self::LEVEL_PARTICIPATING;
        $this->data['objecttable'] = 'generativeaiv2';
    }

    /**
     * Returns a description of what happened.
     *
     * @return string
     */
    public function get_description() {
        return "The user with id '{$this->userid}' viewed the GenerativeAIv2 module with id '{$this->contextinstanceid}'.";
    }

    /**
     * Returns the URL to the module viewed.
     *
     * @return \moodle_url
     */
    public function get_url() {
        return new \moodle_url('/mod/generativeaiv2/view.php', array('id' => $this->contextinstanceid));
    }

    /**
     * Return localised event name.
     *
     * @return string
     */
    public static function get_name() {
        return get_string('eventcoursemoduleviewed', 'mod_generativeaiv2');
    }

    /**
     * Custom validation to check if the event data is valid.
     *
     * @throws \coding_exception
     */
    protected function validate_data() {
        parent::validate_data();
        if (!isset($this->contextinstanceid)) {
            throw new \coding_exception('The context instance ID must be set.');
        }
    }
}